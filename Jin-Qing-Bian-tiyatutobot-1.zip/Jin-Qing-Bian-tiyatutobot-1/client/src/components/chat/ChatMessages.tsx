import { MessageBubble } from "./MessageBubble";
import { TypingIndicator } from "./TypingIndicator";
import { type Message } from "@shared/schema";
import { useEffect, useRef } from "react";

interface ChatMessagesProps {
  messages: Message[];
  isTyping: boolean;
  voiceEnabled?: boolean;
  autoPlay?: boolean;
}

export function ChatMessages({ messages, isTyping, voiceEnabled = false, autoPlay = false }: ChatMessagesProps) {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  return (
    <>
      {messages.map((message) => (
        <MessageBubble 
          key={message.id} 
          message={message} 
          voiceEnabled={voiceEnabled}
          autoPlay={autoPlay}
        />
      ))}
      
      {isTyping && <TypingIndicator />}
      
      <div ref={messagesEndRef} />
    </>
  );
}
