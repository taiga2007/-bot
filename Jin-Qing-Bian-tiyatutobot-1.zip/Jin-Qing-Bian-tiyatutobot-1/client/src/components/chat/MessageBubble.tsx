import { type Message } from "@shared/schema";
import { VoicePlayer } from "./VoicePlayer";

interface MessageBubbleProps {
  message: Message;
  voiceEnabled?: boolean;
  autoPlay?: boolean;
}

export function MessageBubble({ message, voiceEnabled = false, autoPlay = false }: MessageBubbleProps) {
  const isUser = message.sender === 'user';
  const timestamp = new Date(message.timestamp).toLocaleTimeString('ja-JP', {
    hour: '2-digit',
    minute: '2-digit'
  });

  if (isUser) {
    return (
      <div className="flex items-start space-x-2 justify-end animate-slide-up">
        <div className="line-green text-white rounded-2xl rounded-tr-sm px-4 py-3 max-w-[75%] shadow-sm">
          <p>{message.content}</p>
          <div className="text-xs opacity-80 mt-1">{timestamp}</div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-start space-x-2 animate-slide-up">
      <div className="w-8 h-8 line-green rounded-full flex items-center justify-center flex-shrink-0">
        <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
        </svg>
      </div>
      <div className="bg-white border line-border rounded-2xl rounded-tl-sm px-4 py-3 max-w-[75%] shadow-sm">
        <p className="line-text">{message.content}</p>
        <div className="flex items-center justify-between mt-1">
          <div className="text-xs line-text-light">{timestamp}</div>
          {voiceEnabled && !isUser && (
            <VoicePlayer 
              text={message.content} 
              autoPlay={autoPlay}
              className="ml-2"
            />
          )}
        </div>
      </div>
    </div>
  );
}
