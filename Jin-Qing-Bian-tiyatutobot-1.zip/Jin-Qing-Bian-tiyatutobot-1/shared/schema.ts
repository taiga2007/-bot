import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(),
  sender: text("sender").notNull(), // 'user' or 'bot'
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  sessionId: text("session_id").notNull(),
});

export const chatSessions = pgTable("chat_sessions", {
  id: text("id").primaryKey(),
  userId: integer("user_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  lastActivity: timestamp("last_activity").defaultNow().notNull(),
});

export const apiUsage = pgTable("api_usage", {
  id: serial("id").primaryKey(),
  sessionId: text("session_id").notNull(),
  requestCount: integer("request_count").default(0).notNull(),
  lastRequest: timestamp("last_request").defaultNow().notNull(),
  isLimitReached: boolean("is_limit_reached").default(false).notNull(),
});

export const userSettings = pgTable("user_settings", {
  id: serial("id").primaryKey(),
  sessionId: text("session_id").notNull(),
  dialectMode: text("dialect_mode").default("standard").notNull(), // "standard", "tsugaru", "polite_tsugaru"
  voiceEnabled: boolean("voice_enabled").default(false).notNull(),
  autoPlay: boolean("auto_play").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertMessageSchema = createInsertSchema(messages).pick({
  content: true,
  sender: true,
  sessionId: true,
});

export const insertChatSessionSchema = createInsertSchema(chatSessions).pick({
  id: true,
  userId: true,
});

export const insertApiUsageSchema = createInsertSchema(apiUsage).pick({
  sessionId: true,
  requestCount: true,
});

export const insertUserSettingsSchema = createInsertSchema(userSettings).pick({
  sessionId: true,
  dialectMode: true,
  voiceEnabled: true,
  autoPlay: true,
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;
export type InsertChatSession = z.infer<typeof insertChatSessionSchema>;
export type ChatSession = typeof chatSessions.$inferSelect;
export type InsertApiUsage = z.infer<typeof insertApiUsageSchema>;
export type ApiUsage = typeof apiUsage.$inferSelect;
export type InsertUserSettings = z.infer<typeof insertUserSettingsSchema>;
export type UserSettings = typeof userSettings.$inferSelect;
