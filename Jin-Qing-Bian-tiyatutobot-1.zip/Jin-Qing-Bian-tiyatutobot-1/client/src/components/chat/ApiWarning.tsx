import { AlertTriangle } from "lucide-react";

export function ApiWarning() {
  return (
    <div className="bg-yellow-50 border-l-4 border-yellow-400 p-3 mx-4 mb-2">
      <div className="flex items-center">
        <AlertTriangle className="w-4 h-4 text-yellow-400 mr-2" />
        <p className="text-sm text-yellow-800">
          API使用量が上限に近づいています。自動的に代替APIに切り替えます。
        </p>
      </div>
    </div>
  );
}
