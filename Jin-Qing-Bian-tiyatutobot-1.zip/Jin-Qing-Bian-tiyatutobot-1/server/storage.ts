import { users, messages, chatSessions, apiUsage, userSettings, type User, type InsertUser, type Message, type InsertMessage, type ChatSession, type InsertChatSession, type ApiUsage, type InsertApiUsage, type UserSettings, type InsertUserSettings } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  createMessage(message: InsertMessage): Promise<Message>;
  getMessagesBySession(sessionId: string): Promise<Message[]>;
  
  createChatSession(session: InsertChatSession): Promise<ChatSession>;
  getChatSession(id: string): Promise<ChatSession | undefined>;
  updateLastActivity(sessionId: string): Promise<void>;
  
  getApiUsage(sessionId: string): Promise<ApiUsage | undefined>;
  createApiUsage(usage: InsertApiUsage): Promise<ApiUsage>;
  incrementApiUsage(sessionId: string): Promise<ApiUsage>;
  setApiLimitReached(sessionId: string, isReached: boolean): Promise<void>;
  
  getUserSettings(sessionId: string): Promise<UserSettings | undefined>;
  createUserSettings(settings: InsertUserSettings): Promise<UserSettings>;
  updateUserSettings(sessionId: string, settings: Partial<InsertUserSettings>): Promise<UserSettings>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private messages: Map<number, Message>;
  private chatSessions: Map<string, ChatSession>;
  private apiUsages: Map<string, ApiUsage>;
  private userSettings: Map<string, UserSettings>;
  private currentUserId: number;
  private currentMessageId: number;
  private currentSettingsId: number;

  constructor() {
    this.users = new Map();
    this.messages = new Map();
    this.chatSessions = new Map();
    this.apiUsages = new Map();
    this.userSettings = new Map();
    this.currentUserId = 1;
    this.currentMessageId = 1;
    this.currentSettingsId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = this.currentMessageId++;
    const message: Message = {
      ...insertMessage,
      id,
      timestamp: new Date(),
    };
    this.messages.set(id, message);
    return message;
  }

  async getMessagesBySession(sessionId: string): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(message => message.sessionId === sessionId)
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
  }

  async createChatSession(insertSession: InsertChatSession): Promise<ChatSession> {
    const session: ChatSession = {
      id: insertSession.id,
      userId: insertSession.userId || null,
      createdAt: new Date(),
      lastActivity: new Date(),
    };
    this.chatSessions.set(session.id, session);
    return session;
  }

  async getChatSession(id: string): Promise<ChatSession | undefined> {
    return this.chatSessions.get(id);
  }

  async updateLastActivity(sessionId: string): Promise<void> {
    const session = this.chatSessions.get(sessionId);
    if (session) {
      session.lastActivity = new Date();
      this.chatSessions.set(sessionId, session);
    }
  }

  async getApiUsage(sessionId: string): Promise<ApiUsage | undefined> {
    return this.apiUsages.get(sessionId);
  }

  async createApiUsage(insertUsage: InsertApiUsage): Promise<ApiUsage> {
    const usage: ApiUsage = {
      id: Date.now(), // Simple ID generation for in-memory storage
      sessionId: insertUsage.sessionId,
      requestCount: insertUsage.requestCount || 0,
      lastRequest: new Date(),
      isLimitReached: false,
    };
    this.apiUsages.set(insertUsage.sessionId, usage);
    return usage;
  }

  async incrementApiUsage(sessionId: string): Promise<ApiUsage> {
    let usage = this.apiUsages.get(sessionId);
    if (!usage) {
      usage = await this.createApiUsage({ sessionId, requestCount: 1 });
    } else {
      usage.requestCount += 1;
      usage.lastRequest = new Date();
      this.apiUsages.set(sessionId, usage);
    }
    return usage;
  }

  async setApiLimitReached(sessionId: string, isReached: boolean): Promise<void> {
    const usage = this.apiUsages.get(sessionId);
    if (usage) {
      usage.isLimitReached = isReached;
      this.apiUsages.set(sessionId, usage);
    }
  }

  async getUserSettings(sessionId: string): Promise<UserSettings | undefined> {
    return this.userSettings.get(sessionId);
  }

  async createUserSettings(insertSettings: InsertUserSettings): Promise<UserSettings> {
    const settings: UserSettings = {
      id: this.currentSettingsId++,
      sessionId: insertSettings.sessionId,
      dialectMode: insertSettings.dialectMode || "standard",
      voiceEnabled: insertSettings.voiceEnabled || false,
      autoPlay: insertSettings.autoPlay || false,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.userSettings.set(insertSettings.sessionId, settings);
    return settings;
  }

  async updateUserSettings(sessionId: string, updates: Partial<InsertUserSettings>): Promise<UserSettings> {
    let settings = this.userSettings.get(sessionId);
    if (!settings) {
      // Create default settings if none exist
      settings = await this.createUserSettings({ 
        sessionId,
        dialectMode: "standard",
        voiceEnabled: false,
        autoPlay: false
      });
    }
    
    // Update the settings
    if (updates.dialectMode !== undefined) settings.dialectMode = updates.dialectMode;
    if (updates.voiceEnabled !== undefined) settings.voiceEnabled = updates.voiceEnabled;
    if (updates.autoPlay !== undefined) settings.autoPlay = updates.autoPlay;
    settings.updatedAt = new Date();
    
    this.userSettings.set(sessionId, settings);
    return settings;
  }
}

export const storage = new MemStorage();
