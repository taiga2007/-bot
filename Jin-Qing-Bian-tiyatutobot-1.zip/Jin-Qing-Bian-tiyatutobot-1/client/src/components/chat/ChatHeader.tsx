import { ArrowLeft, MoreVertical } from "lucide-react";
import { SettingsDialog } from "./SettingsDialog";
import { HelpDialog } from "./HelpDialog";

interface ChatHeaderProps {
  apiUsage: {
    requestCount: number;
    limit: number;
    isLimitReached: boolean;
  };
  isConnected: boolean;
  settings: {
    dialectMode: string;
    voiceEnabled: boolean;
    autoPlay: boolean;
  };
  onSettingsChange: (newSettings: Partial<{
    dialectMode: string;
    voiceEnabled: boolean;
    autoPlay: boolean;
  }>) => void;
}

export function ChatHeader({ apiUsage, isConnected, settings, onSettingsChange }: ChatHeaderProps) {
  const usagePercentage = ((apiUsage?.requestCount || 0) / (apiUsage?.limit || 10000)) * 100;
  
  return (
    <header className="line-green text-white px-4 py-3 flex items-center justify-between sticky top-0 z-10">
      <div className="flex items-center space-x-3">
        <button className="p-1 hover:bg-opacity-80 rounded-full transition-colors">
          <ArrowLeft className="w-6 h-6" />
        </button>
        
        <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center">
          <svg className="w-5 h-5 text-green-600" fill="currentColor" viewBox="0 0 24 24">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
          </svg>
        </div>
        
        <div>
          <h1 className="font-semibold text-lg">津軽弁AIちゃん</h1>
          <p className="text-xs opacity-90">
            {isConnected ? "オンライン" : "接続中..."} • {
              settings.dialectMode === "standard" ? "標準語" :
              settings.dialectMode === "tsugaru" ? "津軽弁" : "丁寧な津軽弁"
            }
          </p>
        </div>
      </div>
      
      <div className="flex items-center space-x-2">
        <div className={`text-xs px-2 py-1 rounded-full ${
          usagePercentage > 90 ? 'bg-red-500 bg-opacity-80' :
          usagePercentage > 75 ? 'bg-yellow-500 bg-opacity-80' :
          'bg-white bg-opacity-20'
        }`}>
          <span>{(apiUsage?.requestCount || 0).toLocaleString()}</span>/
          <span>{(apiUsage?.limit || 10000).toLocaleString()}</span>
        </div>
        
        <HelpDialog />
        <SettingsDialog 
          settings={settings}
          onSettingsChange={onSettingsChange}
        />
        
        <button className="p-1 hover:bg-opacity-80 rounded-full transition-colors">
          <MoreVertical className="w-5 h-5" />
        </button>
      </div>
    </header>
  );
}
