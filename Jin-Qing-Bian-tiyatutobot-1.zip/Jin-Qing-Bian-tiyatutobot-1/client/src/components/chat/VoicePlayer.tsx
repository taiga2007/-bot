import { useState, useRef, useEffect } from "react";
import { Volume2, VolumeX, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";

interface VoicePlayerProps {
  text: string;
  autoPlay?: boolean;
  className?: string;
}

export function VoicePlayer({ text, autoPlay = false, className = "" }: VoicePlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const speakText = async () => {
    if (!text || text.trim() === "") return;

    // Web Speech API を使用した音声合成
    if ('speechSynthesis' in window) {
      try {
        setIsLoading(true);
        
        // 既存の音声を停止
        window.speechSynthesis.cancel();
        
        const utterance = new SpeechSynthesisUtterance(text);
        
        // 日本語の音声を設定
        const voices = window.speechSynthesis.getVoices();
        const japaneseVoice = voices.find(voice => 
          voice.lang.includes('ja') || voice.name.includes('Japanese')
        );
        
        if (japaneseVoice) {
          utterance.voice = japaneseVoice;
        }
        
        utterance.lang = 'ja-JP';
        utterance.rate = 0.9; // 少しゆっくり
        utterance.pitch = 1.0;
        utterance.volume = 0.8;

        utterance.onstart = () => {
          setIsPlaying(true);
          setIsLoading(false);
        };

        utterance.onend = () => {
          setIsPlaying(false);
        };

        utterance.onerror = (event) => {
          console.error('Speech synthesis error:', event.error);
          setIsPlaying(false);
          setIsLoading(false);
        };

        window.speechSynthesis.speak(utterance);
        
      } catch (error) {
        console.error('Error with speech synthesis:', error);
        setIsLoading(false);
      }
    } else {
      console.warn('Speech synthesis not supported in this browser');
    }
  };

  const stopSpeaking = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsPlaying(false);
    }
  };

  const handleClick = () => {
    if (isPlaying) {
      stopSpeaking();
    } else {
      speakText();
    }
  };

  // 自動再生機能
  useEffect(() => {
    if (autoPlay && text) {
      const timer = setTimeout(() => {
        speakText();
      }, 500); // 少し遅延を入れる
      return () => clearTimeout(timer);
    }
  }, [text, autoPlay]);

  if (!('speechSynthesis' in window)) {
    return null; // 音声合成がサポートされていない場合は何も表示しない
  }

  return (
    <Button
      variant="ghost"
      size="sm"
      onClick={handleClick}
      disabled={isLoading}
      className={`p-1 h-6 w-6 hover:bg-gray-100 dark:hover:bg-gray-800 ${className}`}
    >
      {isLoading ? (
        <Loader2 className="w-3 h-3 animate-spin" />
      ) : isPlaying ? (
        <VolumeX className="w-3 h-3" />
      ) : (
        <Volume2 className="w-3 h-3" />
      )}
    </Button>
  );
}