import { useState, useEffect, useCallback } from "react";
import { useWebSocket } from "./useWebSocket";
import { type Message } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";

interface ApiUsage {
  requestCount: number;
  limit: number;
  isLimitReached: boolean;
}

interface UserSettings {
  dialectMode: string;
  voiceEnabled: boolean;
  autoPlay: boolean;
}

interface ChatHook {
  messages: Message[];
  isTyping: boolean;
  apiUsage: ApiUsage;
  isConnected: boolean;
  showApiWarning: boolean;
  sendMessage: (content: string) => void;
  error: string | null;
  settings: UserSettings;
  updateSettings: (newSettings: Partial<UserSettings>) => void;
}

export function useChat(): ChatHook {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [apiUsage, setApiUsage] = useState<ApiUsage>({
    requestCount: 0,
    limit: 10000,
    isLimitReached: false,
  });
  const [showApiWarning, setShowApiWarning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [settings, setSettings] = useState<UserSettings>({
    dialectMode: "standard",
    voiceEnabled: false,
    autoPlay: false
  });

  const { isConnected, sendMessage: sendWsMessage, lastMessage } = useWebSocket('/ws');

  // Load chat history when session is created
  const { data: chatHistory } = useQuery({
    queryKey: ['/api/sessions', sessionId, 'messages'],
    enabled: !!sessionId,
  });

  // Load API usage when session is created
  const { data: usageData } = useQuery({
    queryKey: ['/api/sessions', sessionId, 'usage'],
    enabled: !!sessionId,
  });

  // Handle WebSocket messages
  useEffect(() => {
    if (!lastMessage) return;

    const { type, ...data } = lastMessage;

    switch (type) {
      case 'session_created':
        setSessionId(data.sessionId);
        break;

      case 'message':
        setMessages(prev => [...prev, data.message]);
        break;

      case 'typing_start':
        setIsTyping(true);
        break;

      case 'typing_stop':
        setIsTyping(false);
        break;

      case 'usage_update':
        setApiUsage(data.usage);
        
        // Show warning if usage is above 75%
        const usagePercentage = (data.usage.requestCount / data.usage.limit) * 100;
        setShowApiWarning(usagePercentage > 75);
        break;

      case 'api_warning':
        setError(data.message);
        setShowApiWarning(true);
        setTimeout(() => setError(null), 5000);
        break;

      case 'error':
        setError(data.message);
        setTimeout(() => setError(null), 5000);
        break;

      default:
        console.log('Unknown WebSocket message type:', type);
    }
  }, [lastMessage]);

  // Load chat history
  useEffect(() => {
    if (chatHistory) {
      setMessages(chatHistory);
    }
  }, [chatHistory]);

  // Load API usage
  useEffect(() => {
    if (usageData) {
      setApiUsage(usageData);
    }
  }, [usageData]);

  const sendMessage = useCallback((content: string) => {
    if (!isConnected) {
      setError("接続が確立されていません");
      return;
    }

    sendWsMessage({
      type: 'chat_message',
      content,
      settings, // Send current settings with the message
    });
  }, [isConnected, sendWsMessage, settings]);

  const updateSettings = useCallback((newSettings: Partial<UserSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
    
    // Send settings update to server
    if (isConnected && sessionId) {
      sendWsMessage({
        type: 'update_settings',
        sessionId,
        settings: { ...settings, ...newSettings },
      });
    }
  }, [isConnected, sendWsMessage, sessionId, settings]);

  return {
    messages,
    isTyping,
    apiUsage,
    isConnected,
    showApiWarning,
    sendMessage,
    error,
    settings,
    updateSettings,
  };
}
