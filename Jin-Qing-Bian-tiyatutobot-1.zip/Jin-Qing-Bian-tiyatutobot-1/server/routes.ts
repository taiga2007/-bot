import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertMessageSchema, insertUserSettingsSchema } from "@shared/schema";
import { v4 as uuidv4 } from "uuid";
import { generateTsugaruResponse } from "./tsugaru-dialect";

const API_LIMIT = 10000;
const FALLBACK_RESPONSES = [
  "申し訳ございませんが、現在API制限に達しているため、基本的な応答のみ提供できます。",
  "APIの使用量が上限に達しました。しばらくお待ちいただいてから再度お試しください。",
  "現在、フォールバックモードで動作しています。基本的なサポートは継続して提供いたします。",
  "API制限のため、簡易応答モードに切り替わりました。ご不便をおかけして申し訳ございません。",
];

interface WebSocketClient {
  ws: WebSocket;
  sessionId: string;
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  const clients = new Map<string, WebSocketClient>();

  // REST API endpoints
  app.get('/api/sessions/:sessionId/messages', async (req, res) => {
    try {
      const { sessionId } = req.params;
      const messages = await storage.getMessagesBySession(sessionId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch messages' });
    }
  });

  app.get('/api/sessions/:sessionId/usage', async (req, res) => {
    try {
      const { sessionId } = req.params;
      const usage = await storage.getApiUsage(sessionId);
      res.json(usage || { requestCount: 0, isLimitReached: false });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch API usage' });
    }
  });

  app.get('/api/sessions/:sessionId/settings', async (req, res) => {
    try {
      const { sessionId } = req.params;
      const settings = await storage.getUserSettings(sessionId);
      res.json(settings || { dialectMode: 'standard', voiceEnabled: false, autoPlay: false });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch settings' });
    }
  });

  app.post('/api/sessions/:sessionId/settings', async (req, res) => {
    try {
      const { sessionId } = req.params;
      const validatedSettings = insertUserSettingsSchema.parse({
        sessionId,
        ...req.body,
      });
      const settings = await storage.updateUserSettings(sessionId, validatedSettings);
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update settings' });
    }
  });

  // WebSocket handling
  wss.on('connection', (ws, request) => {
    const sessionId = uuidv4();
    const client: WebSocketClient = { ws, sessionId };
    clients.set(sessionId, client);

    // Create chat session
    storage.createChatSession({ id: sessionId, userId: null });

    // Send session ID to client
    ws.send(JSON.stringify({
      type: 'session_created',
      sessionId,
    }));

    ws.on('message', async (data) => {
      try {
        const message = JSON.parse(data.toString());
        
        if (message.type === 'chat_message') {
          await handleChatMessage(client, message);
        } else if (message.type === 'update_settings') {
          await handleSettingsUpdate(client, message);
        } else if (message.type === 'ping') {
          ws.send(JSON.stringify({ type: 'pong' }));
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
        ws.send(JSON.stringify({
          type: 'error',
          message: 'Failed to process message',
        }));
      }
    });

    ws.on('close', () => {
      clients.delete(sessionId);
    });

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
      clients.delete(sessionId);
    });
  });

  async function handleChatMessage(client: WebSocketClient, message: any) {
    const { ws, sessionId } = client;
    const { content, settings } = message;

    try {
      // Validate message content
      const validatedMessage = insertMessageSchema.parse({
        content,
        sender: 'user',
        sessionId,
      });

      // Save user message
      const userMessage = await storage.createMessage(validatedMessage);
      
      // Update session activity
      await storage.updateLastActivity(sessionId);

      // Broadcast user message to client
      ws.send(JSON.stringify({
        type: 'message',
        message: userMessage,
      }));

      // Show typing indicator
      ws.send(JSON.stringify({
        type: 'typing_start',
      }));

      // Check API usage and increment
      const usage = await storage.incrementApiUsage(sessionId);
      
      // Broadcast updated usage
      ws.send(JSON.stringify({
        type: 'usage_update',
        usage: {
          requestCount: usage.requestCount,
          limit: API_LIMIT,
          isLimitReached: usage.isLimitReached,
        },
      }));

      let botResponse: string;
      
      // Check if API limit is reached
      if (usage.requestCount >= API_LIMIT || usage.isLimitReached) {
        if (!usage.isLimitReached) {
          await storage.setApiLimitReached(sessionId, true);
          
          // Send API limit warning
          ws.send(JSON.stringify({
            type: 'api_warning',
            message: 'API使用量が上限に達しました。フォールバックモードに切り替えます。',
          }));
        }
        
        // Use fallback response
        botResponse = FALLBACK_RESPONSES[Math.floor(Math.random() * FALLBACK_RESPONSES.length)];
      } else {
        // Get user settings or use defaults
        const userSettings = settings || { dialectMode: "standard" };
        
        // Generate Tsugaru response
        const tsugaruResponse = generateTsugaruResponse(content, usage.requestCount, API_LIMIT);
        
        // Select response based on dialect mode
        switch (userSettings.dialectMode) {
          case "tsugaru":
            botResponse = tsugaruResponse.tsugaru;
            break;
          case "polite_tsugaru":
            botResponse = tsugaruResponse.politeTsugaru;
            break;
          default:
            botResponse = tsugaruResponse.standard;
        }
      }

      // Simulate processing delay
      setTimeout(async () => {
        try {
          // Save bot message
          const botMessage = await storage.createMessage({
            content: botResponse,
            sender: 'bot',
            sessionId,
          });

          // Stop typing indicator and send bot response
          ws.send(JSON.stringify({
            type: 'typing_stop',
          }));

          ws.send(JSON.stringify({
            type: 'message',
            message: botMessage,
          }));
        } catch (error) {
          console.error('Error saving bot message:', error);
          ws.send(JSON.stringify({
            type: 'error',
            message: 'Failed to process response',
          }));
        }
      }, 1000 + Math.random() * 2000); // 1-3 second delay

    } catch (error) {
      console.error('Error handling chat message:', error);
      ws.send(JSON.stringify({
        type: 'error',
        message: 'Invalid message format',
      }));
    }
  }

  async function handleSettingsUpdate(client: WebSocketClient, message: any) {
    const { ws, sessionId } = client;
    const { settings } = message;

    try {
      // Update user settings
      await storage.updateUserSettings(sessionId, settings);
      
      // Confirm settings update
      ws.send(JSON.stringify({
        type: 'settings_updated',
        settings,
      }));
    } catch (error) {
      console.error('Error updating settings:', error);
      ws.send(JSON.stringify({
        type: 'error',
        message: 'Failed to update settings',
      }));
    }
  }



  return httpServer;
}
