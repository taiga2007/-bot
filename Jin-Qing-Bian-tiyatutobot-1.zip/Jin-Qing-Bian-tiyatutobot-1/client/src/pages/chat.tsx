import { ChatHeader } from "@/components/chat/ChatHeader";
import { ChatMessages } from "@/components/chat/ChatMessages";
import { MessageInput } from "@/components/chat/MessageInput";
import { ApiWarning } from "@/components/chat/ApiWarning";
import { useChat } from "@/hooks/useChat";

export default function Chat() {
  const {
    messages,
    isTyping,
    apiUsage,
    isConnected,
    showApiWarning,
    sendMessage,
    error,
    settings,
    updateSettings,
  } = useChat();

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen flex flex-col shadow-lg">
      <ChatHeader 
        apiUsage={apiUsage}
        isConnected={isConnected}
        settings={settings}
        onSettingsChange={updateSettings}
      />
      
      <main className="flex-1 overflow-y-auto p-4 space-y-4 line-gray">
        {/* Date separator */}
        <div className="text-center">
          <div className="inline-block bg-gray-200 line-text-light text-xs px-3 py-1 rounded-full">
            今日
          </div>
        </div>
        
        <ChatMessages 
          messages={messages}
          isTyping={isTyping}
          voiceEnabled={settings.voiceEnabled}
          autoPlay={settings.autoPlay}
        />
      </main>

      {showApiWarning && <ApiWarning />}
      
      <MessageInput 
        onSendMessage={sendMessage}
        disabled={!isConnected}
      />
      
      {error && (
        <div className="fixed top-4 left-1/2 transform -translate-x-1/2 bg-red-500 text-white px-4 py-2 rounded-lg shadow-lg z-50">
          {error}
        </div>
      )}
    </div>
  );
}
