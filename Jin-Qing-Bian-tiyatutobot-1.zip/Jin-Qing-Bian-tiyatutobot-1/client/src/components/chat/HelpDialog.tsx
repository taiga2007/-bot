import { useState } from "react";
import { HelpCircle, MessageCircle, Settings, Volume2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";

export function HelpDialog() {
  const [open, setOpen] = useState(false);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className="text-white hover:bg-white hover:bg-opacity-20 rounded-full transition-colors"
        >
          <HelpCircle className="w-5 h-5" />
        </Button>
      </DialogTrigger>
      
      <DialogContent className="sm:max-w-lg max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <HelpCircle className="w-5 h-5" />
            <span>使い方ガイド</span>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6 pt-4">
          {/* 基本的な使い方 */}
          <div>
            <h3 className="font-semibold flex items-center space-x-2 mb-3">
              <MessageCircle className="w-4 h-4" />
              <span>基本的な使い方</span>
            </h3>
            <div className="space-y-2 text-sm text-gray-700">
              <p>• 下部のメッセージ入力欄にテキストを入力してください</p>
              <p>• Enterキーを押すか送信ボタンをクリックして送信できます</p>
              <p>• Shift+Enterで改行できます</p>
              <p>• AIが津軽弁または標準語で応答します</p>
            </div>
          </div>

          <Separator />

          {/* 津軽弁機能 */}
          <div>
            <h3 className="font-semibold mb-3">津軽弁機能について</h3>
            <div className="space-y-3 text-sm text-gray-700">
              <div>
                <p className="font-medium text-green-700">標準語モード</p>
                <p>普通の日本語で応答します。</p>
              </div>
              <div>
                <p className="font-medium text-green-700">津軽弁モード</p>
                <p>親しみやすい津軽弁で応答します。「んだ」「だべ」などの表現を使います。</p>
              </div>
              <div>
                <p className="font-medium text-green-700">丁寧な津軽弁モード</p>
                <p>津軽弁ながらも丁寧な表現で応答します。「ごんす」「がんす」などを使います。</p>
              </div>
            </div>
          </div>

          <Separator />

          {/* 設定機能 */}
          <div>
            <h3 className="font-semibold flex items-center space-x-2 mb-3">
              <Settings className="w-4 h-4" />
              <span>設定機能</span>
            </h3>
            <div className="space-y-2 text-sm text-gray-700">
              <p>• ヘッダーの設定ボタン（⚙️）から話し方を変更できます</p>
              <p>• 音声読み上げ機能の有効/無効を切り替えられます</p>
              <p>• 自動再生をオンにすると、AIの応答が自動で音声再生されます</p>
            </div>
          </div>

          <Separator />

          {/* 音声機能 */}
          <div>
            <h3 className="font-semibold flex items-center space-x-2 mb-3">
              <Volume2 className="w-4 h-4" />
              <span>音声機能</span>
            </h3>
            <div className="space-y-2 text-sm text-gray-700">
              <p>• 音声読み上げ機能でAIの応答を聞くことができます</p>
              <p>• 津軽弁の応答も音声で楽しめます</p>
              <p>• 設定で自動再生をオンにすると手動操作不要です</p>
              <p>• 各メッセージバブルの音声ボタンで個別再生も可能です</p>
            </div>
          </div>

          <Separator />

          {/* 津軽弁の例 */}
          <div>
            <h3 className="font-semibold mb-3">津軽弁の例</h3>
            <div className="bg-gray-50 p-3 rounded-lg space-y-2 text-sm">
              <div>
                <span className="font-medium">標準語:</span> こんにちは、元気ですか？
              </div>
              <div>
                <span className="font-medium">津軽弁:</span> んだば、元気だべが？
              </div>
              <div>
                <span className="font-medium">丁寧な津軽弁:</span> んだばごんす、元気だべがごんす？
              </div>
            </div>
          </div>

          <Separator />

          {/* API制限について */}
          <div>
            <h3 className="font-semibold mb-3">API使用量について</h3>
            <div className="space-y-2 text-sm text-gray-700">
              <p>• ヘッダーに使用量カウンター（例：100/10,000）が表示されます</p>
              <p>• 使用量が75%を超えると警告が表示されます</p>
              <p>• 上限に達すると自動的にフォールバック応答に切り替わります</p>
              <p>• フォールバックモードでも基本的な会話は継続できます</p>
            </div>
          </div>

          <Separator />

          {/* トラブルシューティング */}
          <div>
            <h3 className="font-semibold mb-3">トラブルシューティング</h3>
            <div className="space-y-2 text-sm text-gray-700">
              <p>• 接続が切れた場合は自動的に再接続を試みます</p>
              <p>• 音声が再生されない場合はブラウザの音声設定を確認してください</p>
              <p>• 問題が続く場合はページを再読み込みしてください</p>
            </div>
          </div>

          {/* フッター */}
          <div className="pt-4 border-t">
            <p className="text-xs text-gray-500 text-center">
              津軽弁チャットボット v1.0 - 青森県津軽地方の方言でお話しします
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}