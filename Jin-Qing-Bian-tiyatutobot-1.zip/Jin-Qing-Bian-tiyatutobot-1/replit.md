# 津軽弁チャットBot Application

## Overview

This is a full-stack chat application built with a React frontend and Express.js backend. The application features a modern LINE-style chat interface with real-time WebSocket communication, API usage tracking, Tsugaru dialect response functionality, voice synthesis, and a responsive mobile-first design. The bot can respond in standard Japanese, casual Tsugaru dialect, or polite Tsugaru dialect based on user settings.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom LINE-inspired design tokens
- **State Management**: TanStack Query for server state, React hooks for local state
- **Routing**: Wouter for lightweight client-side routing

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js with ES modules
- **Real-time Communication**: WebSocket Server (ws library)
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Session Management**: In-memory storage with fallback to PostgreSQL

### Data Storage
- **ORM**: Drizzle with PostgreSQL dialect
- **Schema**: Defined in shared directory for type safety across frontend/backend
- **Tables**: Users, messages, chat sessions, API usage tracking
- **Storage Pattern**: Interface-based storage with memory and database implementations

## Key Components

### Chat System
- Real-time messaging via WebSocket connections
- Message persistence with session-based organization
- Typing indicators and message status
- Mobile-optimized chat interface with LINE-style bubbles
- Tsugaru dialect bot with multiple response modes

### Tsugaru Dialect Features
- **Standard Mode**: Regular Japanese responses
- **Tsugaru Mode**: Casual Tsugaru dialect ("んだ", "だべ", "しでる")
- **Polite Tsugaru Mode**: Formal Tsugaru dialect ("ごんす", "がんす")
- Real-time dialect conversion engine
- Cultural context-aware responses

### Voice Synthesis
- Web Speech API integration for Japanese text-to-speech
- Support for Tsugaru dialect pronunciation
- Manual and automatic playback options
- Individual message voice playback buttons

### Settings & Configuration
- Dialect mode selection (Standard/Tsugaru/Polite Tsugaru)
- Voice settings (enabled/disabled, auto-play)
- Settings persistence per session
- Real-time settings synchronization

### API Usage Tracking
- Request counting per session with configurable limits (10,000 default)
- Fallback responses when API limits are reached
- Visual usage indicators in the chat header
- Automatic limit enforcement and warning system

### UI Components
- Complete shadcn/ui component library
- Custom chat components with voice integration
- Settings and help dialog components
- Responsive design with mobile-first approach
- Japanese text support and LINE-inspired color scheme

### WebSocket Management
- Automatic reconnection with exponential backoff
- Session-based client management
- Error handling and connection status indicators
- Message queuing during disconnections

## Data Flow

1. **Chat Initialization**: Client connects via WebSocket, receives unique session ID
2. **Message Flow**: User input → WebSocket → Server processing → Database storage → Broadcast to clients
3. **API Tracking**: Each message increments usage counter, triggers fallback when limit reached
4. **State Synchronization**: React Query manages server state, WebSocket handles real-time updates

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL client
- **@tanstack/react-query**: Server state management
- **drizzle-orm**: Type-safe database ORM
- **ws**: WebSocket server implementation
- **express**: Web application framework

### UI Dependencies
- **@radix-ui/***: Headless UI components
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Component variant management
- **lucide-react**: Icon library

### Development Dependencies
- **vite**: Build tool and development server
- **typescript**: Type safety
- **tsx**: TypeScript execution for development

## Deployment Strategy

### Build Process
- Frontend: Vite builds optimized production bundle to `dist/public`
- Backend: esbuild bundles server code to `dist/index.js`
- Shared types: Included in both builds for consistency

### Environment Requirements
- Node.js environment with ES module support
- PostgreSQL database (DATABASE_URL environment variable)
- WebSocket support for real-time features

### Production Considerations
- Static file serving handled by Express in production
- WebSocket connections require proper proxy configuration
- Database migrations managed via Drizzle Kit
- Session persistence requires database storage in production

### Development vs Production
- Development: Vite dev server with HMR, in-memory storage fallback
- Production: Express serves static files, database-backed sessions
- Environment detection via NODE_ENV variable