// 津軽弁変換機能
export interface TsugaruResponse {
  standard: string;
  tsugaru: string;
  politeTsugaru: string;
}

// 津軽弁の基本的な変換ルール
const tsugaruConversions: { [key: string]: string } = {
  // 基本的な挨拶
  "こんにちは": "んだば",
  "おはよう": "おはよごんす",
  "こんばんは": "ばんげおづかれさま",
  "ありがとう": "ありがとごんす",
  "すみません": "すまんちゃ",
  "さようなら": "また来いへ",
  
  // よく使う言葉
  "はい": "んだ",
  "いいえ": "だめだ",
  "そうです": "んだども",
  "そうですね": "んだなあ",
  "わかりました": "わがった",
  "大丈夫": "だいじょばね",
  "すごい": "んめえ",
  "おいしい": "うめえ",
  "寒い": "しばれる",
  "疲れた": "こんわった",
  
  // 文末詞
  "です": "だじゃ",
  "ます": "がんす",
  "だよ": "だべ",
  "でしょう": "だべさ",
  "ですよ": "だべよ",
  "ですか": "だべが",
  
  // 動詞の変換
  "食べる": "くう",
  "飲む": "のむ",
  "行く": "いぐ",
  "来る": "くる",
  "見る": "みる",
  "聞く": "きぐ",
  "話す": "しゃべる",
  "寝る": "ねる",
  "起きる": "おぎる",
  
  // 助詞の変換
  "を": "ば",
  "から": "はんで",
  "ので": "はんで",
  "けれど": "だばって",
  "だから": "だはんで",
  "でも": "だばって",
};

const politeTsugaruConversions: { [key: string]: string } = {
  "こんにちは": "んだばごんす",
  "おはよう": "おはよございがんす",
  "こんばんは": "ばんげおづかれさまでごんす",
  "ありがとう": "ありがとごんした",
  "すみません": "もうしわけござらん",
  "さようなら": "またおいでくなんせ",
  
  "はい": "んだごんす",
  "いいえ": "いんねごんす",
  "そうです": "んだごんす",
  "そうですね": "んだごんすなあ",
  "わかりました": "わがりがんした",
  "大丈夫": "だいじょばねごんす",
};

export function convertToTsugaru(text: string, mode: "tsugaru" | "polite_tsugaru" = "tsugaru"): string {
  let result = text;
  const conversions = mode === "polite_tsugaru" ? politeTsugaruConversions : tsugaruConversions;
  
  // 基本的な変換を適用
  for (const [standard, tsugaru] of Object.entries(conversions)) {
    const regex = new RegExp(standard, "g");
    result = result.replace(regex, tsugaru);
  }
  
  // より複雑な変換ルール
  if (mode === "tsugaru") {
    // 「〜している」→「〜してる」→「〜しでる」
    result = result.replace(/している/g, "しでる");
    result = result.replace(/してる/g, "しでる");
    
    // 「〜ている」→「〜でる」
    result = result.replace(/ている/g, "でる");
    
    // 「〜だった」→「〜だったじゃ」
    result = result.replace(/だった/g, "だったじゃ");
    
    // 「〜かった」→「〜がった」
    result = result.replace(/かった/g, "がった");
    
    // 「し」→「す」（語中）
    result = result.replace(/し([あいうえお])/g, "す$1");
  }
  
  return result;
}

export function generateTsugaruResponse(userMessage: string, currentUsage: number, limit: number): TsugaruResponse {
  const lowerMessage = userMessage.toLowerCase();
  let standardResponse = "";
  
  // 基本的な応答パターン
  if (lowerMessage.includes('津軽') || lowerMessage.includes('つがる')) {
    standardResponse = "津軽の話をしたいんですね！津軽は美しい場所で、独特な方言があります。";
  } else if (lowerMessage.includes('天気') || lowerMessage.includes('weather')) {
    standardResponse = "今日の天気は晴れ時々曇りです。津軽の冬は雪が多いですよ。";
  } else if (lowerMessage.includes('時間') || lowerMessage.includes('time')) {
    standardResponse = `現在の時刻は${new Date().toLocaleTimeString('ja-JP')}です。`;
  } else if (lowerMessage.includes('ありがとう') || lowerMessage.includes('thank')) {
    standardResponse = "どういたしまして！他にご質問がございましたら、お気軽にお聞かせください。";
  } else if (lowerMessage.includes('こんにちは') || lowerMessage.includes('hello') || lowerMessage.includes('hi')) {
    standardResponse = "こんにちは！本日はどのようなことでお手伝いできますでしょうか？";
  } else if (lowerMessage.includes('方言') || lowerMessage.includes('dialect')) {
    standardResponse = "津軽弁は青森県の津軽地方で話されている方言です。とても温かみのある言葉です。";
  } else {
    standardResponse = "ご質問をいただき、ありがとうございます。津軽弁でお話しすることもできますよ！";
  }
  
  return {
    standard: standardResponse,
    tsugaru: convertToTsugaru(standardResponse, "tsugaru"),
    politeTsugaru: convertToTsugaru(standardResponse, "polite_tsugaru")
  };
}