import { useState } from "react";
import { Settings, Volume2, VolumeX } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";

interface SettingsDialogProps {
  settings: {
    dialectMode: string;
    voiceEnabled: boolean;
    autoPlay: boolean;
  };
  onSettingsChange: (newSettings: Partial<{
    dialectMode: string;
    voiceEnabled: boolean;
    autoPlay: boolean;
  }>) => void;
}

export function SettingsDialog({ settings, onSettingsChange }: SettingsDialogProps) {
  const [open, setOpen] = useState(false);

  const dialectOptions = [
    { value: "standard", label: "標準語", description: "普通の日本語で応答します" },
    { value: "tsugaru", label: "津軽弁", description: "親しみやすい津軽弁で応答します" },
    { value: "polite_tsugaru", label: "丁寧な津軽弁", description: "丁寧な津軽弁で応答します" }
  ];

  const handleDialectChange = (value: string) => {
    onSettingsChange({ dialectMode: value });
  };

  const handleVoiceToggle = (enabled: boolean) => {
    onSettingsChange({ voiceEnabled: enabled });
  };

  const handleAutoPlayToggle = (enabled: boolean) => {
    onSettingsChange({ autoPlay: enabled });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className="text-white hover:bg-white hover:bg-opacity-20 rounded-full transition-colors"
        >
          <Settings className="w-5 h-5" />
        </Button>
      </DialogTrigger>
      
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Settings className="w-5 h-5" />
            <span>チャット設定</span>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6 pt-4">
          {/* 方言設定 */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">話し方モード</Label>
            <Select value={settings.dialectMode} onValueChange={handleDialectChange}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="話し方を選択" />
              </SelectTrigger>
              <SelectContent>
                {dialectOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    <div>
                      <div className="font-medium">{option.label}</div>
                      <div className="text-xs text-muted-foreground">{option.description}</div>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Separator />

          {/* 音声設定 */}
          <div className="space-y-4">
            <Label className="text-sm font-medium flex items-center space-x-2">
              {settings.voiceEnabled ? (
                <Volume2 className="w-4 h-4" />
              ) : (
                <VolumeX className="w-4 h-4" />
              )}
              <span>音声機能</span>
            </Label>
            
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm">音声読み上げ</Label>
                  <p className="text-xs text-muted-foreground">AIの応答を音声で読み上げます</p>
                </div>
                <Switch
                  checked={settings.voiceEnabled}
                  onCheckedChange={handleVoiceToggle}
                />
              </div>
              
              {settings.voiceEnabled && (
                <div className="flex items-center justify-between pl-6">
                  <div>
                    <Label className="text-sm">自動再生</Label>
                    <p className="text-xs text-muted-foreground">応答が来たら自動で音声を再生します</p>
                  </div>
                  <Switch
                    checked={settings.autoPlay}
                    onCheckedChange={handleAutoPlayToggle}
                  />
                </div>
              )}
            </div>
          </div>

          <Separator />

          {/* 現在の設定表示 */}
          <div className="bg-gray-50 p-3 rounded-lg">
            <Label className="text-xs font-medium text-gray-600">現在の設定</Label>
            <div className="mt-2 space-y-1 text-sm">
              <div>
                話し方: <span className="font-medium">
                  {dialectOptions.find(opt => opt.value === settings.dialectMode)?.label}
                </span>
              </div>
              <div>
                音声機能: <span className="font-medium">
                  {settings.voiceEnabled ? "有効" : "無効"}
                </span>
              </div>
              {settings.voiceEnabled && (
                <div>
                  自動再生: <span className="font-medium">
                    {settings.autoPlay ? "有効" : "無効"}
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}